# Локальные ИИ — делегирование (плагин Kimi Work)

Плагин отдаёт простые текстовые задачи локальным моделям **AI Manager**
(https://iox-ai-manager.duckdns.org:8443, сервер ioxvorm: gpt-oss-20b для кода, qwen3.6-35b для текстов),
чтобы агент Kimi экономил токены. Kimi — контроллер: решает, что делегировать, проверяет
результат и выполняет задачу сам, если локальная модель не справилась или недоступна.

## Что внутри

- `scripts/mcp_server.py` — MCP-сервер (stdio, только стандартная библиотека Python).
  Инструменты:
  - `local_llm(task, files?, output_file?, model?, compact?, line_numbers?, max_tokens?, timeout_sec?, max_return_chars?)`
    — делегировать задачу; файлы читает сервер, в контекст агента идёт только результат;
    большие входы нарезаются на части (map-reduce);
  - `local_llm_wait(job_id)` — дождаться фоновой задачи (модель грузится 30-60 с);
  - `local_llm_status()` — доступность AI Manager, активная модель, очередь.
- `skills/local-ai-delegate/SKILL.md` — правила контроллера: когда делегировать, когда нет,
  как проверять результат и когда выполнять задачу самостоятельно.

## Настройка (обязательно один раз)

Серверу нужны адрес AI Manager и пароль (`AIM_PASSWORD` из `.env` сервера). Пароль в плагин
не вшит — задайте его одним из способов:

1. **Файл конфигурации** (рекомендуется):
   создайте `%LOCALAPPDATA%\local-ai-delegate\config.json` (т.е.
   `C:\Users\<имя>\AppData\Roaming\local-ai-delegate\config.json`):

   ```json
   {
     "url": "https://iox-ai-manager.duckdns.org:8443",
     "password": "пароль из .env AI Manager"
   }
   ```

2. **Переменные окружения**: `AIM_URL` и `AIM_PASSWORD`
   (именно так — env в манифесте плагина имеет приоритет над файлом).

Дополнительные переменные (в env или в том же JSON): `DELEGATE_CODE_MODEL`,
`DELEGATE_TEXT_MODEL`, `DELEGATE_REASON_MODEL`, `DELEGATE_DEFAULT_MODEL`,
`DELEGATE_TIMEOUT`, `DELEGATE_WAIT_TIMEOUT`, `DELEGATE_MAX_CHUNKS`, `DELEGATE_PROJECT`.

## Требования

- **Python 3.10+** в PATH (для запуска MCP-сервера плагина). На Windows ставится
  с python.org (отметить «Add python.exe to PATH»).
- Доступ к серверу AI Manager по сети (интернет или локальная сеть).

## Как пользоваться

После установки плагина просто просите агента на естественном языке, например:

- «Сделай сводку этого лога через локальную модель»
- «Переведи README на русский локальной моделью, запиши в README.ru.md»
- «Напиши докстринги во все функции этого файла через локальный ИИ»

Проверка конфигурации: попросите агента вызвать `local_llm_status()` или выполните вручную:

```bat
python scripts\mcp_server.py   %LOCALAPPDATA%\local-ai-delegate\config.json
```

(сервер ждёт JSON-RPC через stdin; для ручной проверки удобнее сразу задать вопрос агенту).

## Лог

Вызовы пишутся в `%LOCALAPPDATA%\local-ai-delegate\delegate_log.jsonl`.
